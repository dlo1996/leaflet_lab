//function to instantiate the Leaflet map
function createMap(){
    //create the map
    var map = L.map('map', {
        center: [20, 0],
        zoom: 2
    });

//add OSM base tilelayer
    L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
    }).addTo(map);

//call getData function
    getData(map);
};
function onEachFeature(feature, layer) {
    var popupContent = "";
    if (feature.properties) {
        for (var property in feature.properties){
            popupContent += "<p>" + property + ": " + feature.properties[property] + "</p>";
        }
        layer.bindPopup(popupContent);
    };
};

//function getData(map){
    //$.ajax("data/map.geojson", {
        //dataType: "json",
        //success: function(response){

          //var geojsonMarkerOptions = {
            //radius: 8,
            //fillColor: "#ff7800",
            //color: "#000",
            //weight: 1,
            //opacity: 1,
            //fillOpacity: 0.8
          //};

            //L.geoJson(response, {
              //onEachFeature: onEachFeature,
              //pointToLayer: function (onEachFeature, latlng){
                //return L.circleMarker(latlng, geojsonMarkerOptions);
              //},
              //filter: function(feature, layer) {
                //if (feature.properties.Pop_2015 > 20 ) {
                  //return 'true'
                //}
              //}
            //}).addTo(map);

        //}
    //});
//};
function getData(map){
  $.ajax("data/map.geojson", {
    dataType: "json",
    success: function(response){
      createPropSymbols(response, map);
    }
  });
};
function createPropSymbols(data, map){
  //var attribute: "total";
  var geojsonMarkerOptions = {
    radius: 8,
    fillColor: "#ff7800",
    color:"#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
  };

//function calcPropRadius(attValue){
  //var scaleFactor = 50;
  //var area = attValue * scaleFactor;
  //var radius = Math.sqrt(area/Math.PI);
  //return radius;
//};
  L.geoJson(data, {
    pointToLayer: function (feature, latlng){
      return L.circleMarker(latlng, geojsonMarkerOptions);
      //var attValue = Number(feature.properties[attribute]);
      //geojsonMarkerOptions.radius = calcPropRadius(attValue);
      //console.log(feature.properties, attValue);
      //return L.circleMarker(latlng, geojsonMarkerOptions);
    }
  }).addTo(map)
};




$(document).ready(createMap);
